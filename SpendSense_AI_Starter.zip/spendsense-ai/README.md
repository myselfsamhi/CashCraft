# SpendSense AI — Intelligent Money Manager

A beginner-friendly fintech project starter with a responsive dashboard, transaction tracker, budget planner, transparent rule-based insights, and PayPal Sandbox checkout.

## Features
- Responsive dashboard with income, expenses, savings, and spending categories.
- Add and delete income/expense records.
- Browser-local persistence using `localStorage`.
- Monthly budget tracker and sample savings goal.
- Explainable, rule-based spending insights (not a trained AI model).
- PayPal Sandbox order creation and capture through a Node/Express backend.

## Requirements
- Node.js 18 or newer
- A PayPal Developer account and Sandbox REST app credentials

## Run locally
1. Extract the ZIP and open the project folder in VS Code.
2. Open a terminal in the project folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
5. In the PayPal Developer Dashboard, switch to **Sandbox**, open **Apps & Credentials**, and copy the Sandbox app's Client ID and Secret into `.env`.
6. Start the app:
   ```bash
   npm start
   ```
7. Open `http://localhost:3000`.

## PayPal Sandbox test
- Create/use a Sandbox Personal account as the buyer and a Sandbox Business account as the seller.
- Open **PayPal Sandbox** inside SpendSense and use the test checkout button.
- Sign in to the PayPal checkout popup with the Sandbox Personal buyer account.
- Review the mock transaction in the Sandbox Business account.

Sandbox transactions are simulated and do not move real money. This project uses the PayPal JavaScript SDK v5 checkout flow with server-side Orders API create/capture endpoints as a straightforward learning starter. Check PayPal's current SDK migration guidance before using it as the basis of a production integration.

## Important security notes
- Never put `PAYPAL_CLIENT_SECRET` in browser JavaScript or commit `.env` to Git.
- The backend creates and captures orders; the browser only receives the order ID.
- This prototype stores manually entered records in the current browser only. It does not connect to a bank account or sync transactions from PayPal into the expense tracker.
- The AI Insights page currently uses simple explainable rules. To add an actual AI model, connect a model through a secure server endpoint and clearly disclose what data is sent.
- This is an educational prototype, not a bank, payment processor, or financial-advice service.

## Suggested next upgrades
- User login and a database (SQLite/PostgreSQL).
- Export monthly reports to CSV/PDF.
- Real AI summaries through a protected backend.
- Verified PayPal webhook handling and transaction reconciliation.
- Multi-currency support and accessible UI refinements.
